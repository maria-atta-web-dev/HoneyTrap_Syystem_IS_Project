</div>
</div>
<footer>
    <div class="container text-center">
        <p class="mb-0">&copy;
            <?php echo date('Y'); ?> SecureSite System. All Rights Reserved.
        </p>
        <small>Protected by HoneyTrap Architecture</small>
    </div>
</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>